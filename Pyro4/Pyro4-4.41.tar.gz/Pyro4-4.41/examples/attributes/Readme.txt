This is an example that shows direct remote attribute access.

