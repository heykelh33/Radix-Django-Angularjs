This example shows the use of the instance_mode option when exposing a class.
It also shows the old style use of the expose decorator.

Please make sure a name server is running somewhere first,
before starting the server and client.
