:mod:`Pyro4.core` --- core Pyro logic
=====================================

.. automodule:: Pyro4.core
    :members: URI, Proxy, Daemon, DaemonObject, callback, batch, async, expose, oneway, current_context

